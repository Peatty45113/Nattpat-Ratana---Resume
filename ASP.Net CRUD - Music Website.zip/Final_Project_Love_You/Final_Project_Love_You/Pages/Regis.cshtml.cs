using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Project_Love_You.Pages
{
    public class RegisModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
