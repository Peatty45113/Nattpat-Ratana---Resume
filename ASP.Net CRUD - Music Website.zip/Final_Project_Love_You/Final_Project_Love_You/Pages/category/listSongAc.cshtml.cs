using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Final_Project_Love_You.Pages.category
{
    public class listSongAcModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
