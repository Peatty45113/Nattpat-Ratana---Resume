-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 06, 2022 at 02:26 AM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `music`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `CategoryID` int(255) DEFAULT NULL,
  `CategoryName` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`CategoryID`, `CategoryName`) VALUES
(1, 'Rock'),
(2, 'Rap'),
(3, 'Jazz'),
(4, 'EDM'),
(5, 'Country'),
(6, 'Raggae'),
(7, 'Classic');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `OrderID` int(255) NOT NULL,
  `ContactName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Address` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `SongName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `TransportName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`OrderID`, `ContactName`, `Address`, `SongName`, `TransportName`) VALUES
(1, 's', 's', 's', 's'),
(2, 'Prayut Chan O Cha', '112 Germany', 'Phet Thae', 'EMS'),
(3, 'SSS SSS', 'SSSS', 'SSS', 'EMS');

-- --------------------------------------------------------

--
-- Table structure for table `songs_table`
--

CREATE TABLE `songs_table` (
  `SongID` int(255) NOT NULL,
  `SongName` varchar(20) DEFAULT NULL,
  `Artist` varchar(20) DEFAULT NULL,
  `CategoryID` varchar(20) DEFAULT NULL,
  `Link` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `songs_table`
--

INSERT INTO `songs_table` (`SongID`, `SongName`, `Artist`, `CategoryID`, `Link`) VALUES
(1, 'Kessen Spirit', 'CHiCO with HoneyWork', '1', 'https://www.youtube.com/watch?v=ErqUUYWfOBo'),
(2, 'yoru ni kakeru', 'Yoasobi', '1', 'https://www.youtube.com/watch?v=x8VYWazR5mE&bpctr=1667681905&pbjreload=101'),
(3, 'Edison', 'Maneki-Neko', '2', 'https://www.youtube.com/watch?v=dbGCrX_zPfs'),
(4, 'All Blues', 'Miles Davis', '3', 'https://www.youtube.com/watch?v=-488UORrfJ0');

-- --------------------------------------------------------

--
-- Table structure for table `users_table`
--

CREATE TABLE `users_table` (
  `UserID` int(255) NOT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `Pass` varchar(20) DEFAULT NULL,
  `ContactName` varchar(20) DEFAULT NULL,
  `Address1` varchar(20) DEFAULT NULL,
  `Address2` varchar(20) DEFAULT NULL,
  `IsAdmin` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_table`
--

INSERT INTO `users_table` (`UserID`, `UserName`, `Pass`, `ContactName`, `Address1`, `Address2`, `IsAdmin`) VALUES
(1, 'SiaO', '1112', 'Germany Croptop Walk', 'Germany', '', ''),
(3, 'sss', 'sss', 'sss', 'sss', 'sss', ''),
(4, 'sd', 'sd', 'sd', 'sd', 'sd', ''),
(6, 'g', 'g', 'g', 'g', 'g', ''),
(7, 'T', 'T', 'TT', 'T', 'T', ''),
(8, '123', '123', '123', '123', '123', ''),
(9, 'dada', '555', 'tea cup E', 'ad', 'ad', ''),
(15, 'awd', 'awdaw', 'awdaw', '', '', ''),
(16, 'sss', 'sss', 'sss', '', '', ''),
(17, 'ssss', 'sss', 'sss', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `songs_table`
--
ALTER TABLE `songs_table`
  ADD PRIMARY KEY (`SongID`);

--
-- Indexes for table `users_table`
--
ALTER TABLE `users_table`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `OrderID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `songs_table`
--
ALTER TABLE `songs_table`
  MODIFY `SongID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000;

--
-- AUTO_INCREMENT for table `users_table`
--
ALTER TABLE `users_table`
  MODIFY `UserID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
